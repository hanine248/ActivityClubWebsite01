﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ActivityClub.Core.DTOs
{
    public class EventGuideDTO
    {
        public int Eventguideid { get; set; }

        public int? Eventid { get; set; }

        public int? Guideid { get; set; }
    }
}
